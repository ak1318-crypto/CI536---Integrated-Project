<?php
    session_start();
    if (!isset($_SESSION["status"])) {
        header("Location:http://ak1318.brighton.domains/groupproject/login.php");
        exit();
    } 
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <!-- css file link-->

  <link rel="stylesheet" href="CSS/style.css">
  
  <link rel="stylesheet" href=" CSS/normalize.css">

  <!-- font awesome file link -->

  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">

  <!-- favicon link -->

  <link rel="icon" type="image/x-icon" href="images/CSS3_logo.png">

  <title>Cyber Security | Home</title>

</head>

<body>

  <!-- header start -->

  <header class="header">

    <a href="#" class="logo"><i class="fa-solid fa-user-secret"></i>CyberSecurity.</a>

    <div class="fas fa-bars"></div>

    <nav class="navbar">

      <ul>

        <li><a href="#home">home</a></li>
        <li><a href="https://ak1318.brighton.domains/groupproject/registration_form.php">Register</a></li>
        <li><a href= "https://ak1318.brighton.domains/groupproject/login.php"> Login </a></li>
        <li><a href="#info">Info</a></li>
      
        
        <!-- <li><a href="#team">team</a></li> -->
        <!--<li><a href="#contact">contact</a></li> -->
      </ul>



    </nav>




  </header>

  <!-- header end -->

  <!-- home section starts-->

  <section id="home" class="home">

    <h1 class="banner">Cyber Security</h1>
    <h3 class="slogan">Online security is important for keeping our data safe</h3>
    <!--<a href="#"><button>learn more</button></a>-->


    <!-- wave effect  -->

    <div class="wave wave1"></div>
    <div class="wave wave2"></div>
    <div class="wave wave3"></div>




    <!-- Rotating nuts  -->

    <div class="fas fa-cog nut1"></div>
    <div class="fas fa-cog nut2"></div>
    



  </section>

  <!-- home section ends-->

  <!-- about section start -->

  <section id="about" class="about">

    <h1 class="heading">About CyberSecurity</h1>



<!-- jquery file link -->
  
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>





  <!-- custom js file link -->

  <script src="js/main.js"></script>

  

</body>
</html>
